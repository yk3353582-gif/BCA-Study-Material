# BCA Notes Site

## Naveen notes/program add karayla (kontya file madhe)
1. `<subject-folder>/index.html` ughada (e.g. `java/index.html`).
2. Khali navin topic block copy-paste kar:
   ```html
   <div class="topic" id="topic-id">
     <h2>3. Topic Title</h2>
     <p class="note">Notes text here.</p>
     <pre><code>// program code here</code></pre>
   </div>
   ```
3. Tyachyach page var sidebar madhe ek link add kar:
   ```html
   <a href="#topic-id">3. Topic Title</a>
   ```
4. `id="topic-id"` ani `href="#topic-id"` same asle pahije (match).

## Naveen subject add karayla
1. Root madhe navin folder banav (e.g. `dbms`).
2. `_subject-template.html` copy karun `dbms/index.html` mhanun save kar.
3. File madhla `__SUBJECT__` word replace kar subject name ne.
4. `index.html` (home page) madhe navin `<a class="card">` card add kar, tya subject kade point karnara.

## Website public karayla (GitHub Pages — free)
1. github.com var account banav (jar nasel tr).
2. Navin repository banav, naav dye — e.g. `bca-notes`.
3. Ya folder madhlya sagalya files (index.html, style.css, sagle subject folders) tya repository madhe upload kar
   (GitHub website var "uploading an existing file" option vaparun, ki drag-drop pn karta yeta).
4. Repository chya **Settings > Pages** madhe ja.
5. "Branch" madhe `main` nivad, folder `/ (root)` thev, ani **Save** kar.
6. 1-2 minute wait kar — GitHub tula ek live link deil, jasa:
   `https://yourusername.github.io/bca-notes/`
7. Ha link konalapn share kar shakto — public zali website.

## Update karayla nantr
- Konatipn file change kar, GitHub var re-upload/commit kar — website automatically update hoil.
